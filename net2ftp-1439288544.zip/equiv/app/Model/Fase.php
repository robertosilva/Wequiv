<?php
App::uses('AppModel', 'Model');
/**
 * Fase Model
 *
 * @property Exercicio $Exercicio
 * @property Sessao $Sessao
 */
class Fase extends AppModel {


	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * hasAndBelongsToMany associations
 *
 * @var array
 */
	public $hasAndBelongsToMany = array(
		'Exercicio' => array(
			'className' => 'Exercicio',
			'joinTable' => 'exercicios_fases',
			'foreignKey' => 'fase_id',
			'associationForeignKey' => 'exercicio_id',
			'unique' => 'keepExisting',
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'finderQuery' => '',
		),
		'Sessao' => array(
			'className' => 'Sessao',
			'joinTable' => 'fases_sessaos',
			'foreignKey' => 'fase_id',
			'associationForeignKey' => 'sessao_id',
			'unique' => 'keepExisting',
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'finderQuery' => '',
		)
	);

}
