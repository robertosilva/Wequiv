<?php
App::uses('AppModel', 'Model');
/**
 * Exercicio Model
 *
 * @property EstimulosExercicio $EstimulosExercicio
 * @property Fase $Fase
 */
class Exercicio extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'name';



        //The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * belongsTo associations
 *
 * @var array
 */
   public $belongsTo = array(
            'Reforco' => array(
			'className' => 'Reforco',
			'foreignKey' => 'reforco_id',
			'conditions' => '',
			'fields' => '',
			'order' => '',
			
		)
                        
	);

/**
 * hasMany associations
 *
 * @var array
 */
	public $hasMany = array(
		'EstimulosExercicio' => array(
			'className' => 'EstimulosExercicio',
			'foreignKey' => 'exercicio_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);


/**
 * hasAndBelongsToMany associations
 *
 * @var array
 */
	public $hasAndBelongsToMany = array(
		'Fase' => array(
			'className' => 'Fase',
			'joinTable' => 'exercicios_fases',
			'foreignKey' => 'exercicio_id',
			'associationForeignKey' => 'fase_id',
			'unique' => 'keepExisting',
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'finderQuery' => '',
		)
	);

}
