<?php
App::uses('AppModel', 'Model');
/**
 * Estimulo Model
 *
 * @property EstimulopsExercicio $EstimulopsExercicio
 */
class Estimulo extends AppModel {

         public $actsAs = array(
        'Upload.Upload' => array(
           'image_format' => array (
               'path' => '{ROOT}{DS}webroot{DS}files{DS}',
               
                        'fields' => array (
                               'dir'=>'path_image'
                                 )),
            'audio_format' => array (
                 'path' => '{ROOT}{DS}webroot{DS}files{DS}',
                        'fields' => array (
                                'dir'=>'path_audio'
                                 )) 
        )
    );
    
/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'name';


	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * hasOne associations
 *
 * @var array
 */	
            public $hasMany = array(
		'EstimulosExercicio' => array(
			'className' => 'EstimulosExercicio',
			'foreignKey' => 'exercicio_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);

            
            
            
            
            
            
            
            
            
            
            
}
