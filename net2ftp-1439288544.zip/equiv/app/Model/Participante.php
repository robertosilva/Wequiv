<?php
App::uses('AppModel', 'Model');
/**
 * Participante Model
 *
 */
class Participante extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'name';

/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(
		'nome_projeto' => array(
                        
                        'rule' => '/[a-zA-Z]+$/',
			'message' => 'Utilize nomes válidos',
			//'allowEmpty' => true,
			//'required' => true,
			//'last' => false, // Stop validation after this rule
			//'on' => 'create', // Limit validation to 'create' or 'update' operations
			
			
		),
		'name' => array(
			
                        'rule' => '/[a-zA-Z]+$/',
			'message' => 'Utilize nomes válidos',
			//'allowEmpty' => false,
			//'required' => true,
			//'last' => false, // Stop validation after this rule
			//'on' => 'create', // Limit validation to 'create' or 'update' operations
			
			
		),
		'nome_pai' => array(
			'rule' => '/[a-zA-Z]+$/',
			'message' => 'Utilize nomes válidos',
			'allowEmpty' => true,
			//'required' => false,
			//'last' => false, // Stop validation after this rule
			//'on' => 'create', // Limit validation to 'create' or 'update' operations
		),
		'nome_mae' => array(
			'rule' => '/[a-zA-Z]+$/',
			'message' => 'Utilize nomes válidos',
			//'allowEmpty' => false,
			//'required' => true,
			//'last' => false, // Stop validation after this rule
			//'on' => 'create', // Limit validation to 'create' or 'update' operations
		),
		'endereco' => array(
			'alphaNumeric' => array(
				'rule' => array('alphaNumeric'),
				'message' => 'Utilize somente letras e números. ',
				'allowEmpty' => true,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'numero' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Somente números',
				'allowEmpty' => true,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'complemento' => array(
			'alphaNumeric' => array(
				'rule' => array('alphaNumeric'),
				'message' => 'Utilize um endereço válido',
				'allowEmpty' => true,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'cep' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Somente números',
				'allowEmpty' => true,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'telefone' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Somente números',
				'allowEmpty' => true,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);

        public $belongsTo = array(
		'Sexo' => array(
			'className' => 'Sexo',
			'foreignKey' => 'sexo_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Escolaridade' => array(
			'className' => 'Escolaridade',
			'foreignKey' => 'escolaridade_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Estado' => array(
			'className' => 'Estado',
			'foreignKey' => 'estado_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Usuario' => array(
			'className' => 'Usuario',
			'foreignKey' => 'usuario_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
            
            
            
	);
    
        
        
}
