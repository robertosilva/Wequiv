<?php
App::uses('AppModel', 'Model');
App::uses('BlowfishPasswordHasher', 'Controller/Component/Auth');
/**
 * Usuario Model
 *
 * @property Participante $Participante
 */
class Usuario extends AppModel {

    public function beforeSave($options = array()) {
        
        
    if (isset($this->data['Usuario']['password'])) {
        $passwordHasher = new BlowfishPasswordHasher();
        $this->data['Usuario']['password'] = $passwordHasher->hash(
            $this->data['Usuario']['password']
        );
    }
    return true;
}

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'name';

/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(
		'username' => array(
			
				'rule' => 'alphaNumeric',
				'message' => 'Utilize somente letras e números. ',
				'allowEmpty' => false,
				'required' => true,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			
			
		),
		'name' => array(
			'rule' => '/[a-zA-Z]+$/',
				'message' => 'Utilize nomes válidos',
				//'allowEmpty' => false,
				'required' => true,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
            
		'password' => array(
                    'required' => array(
                         'rule' => array('notEmpty'),
                         'message' => 'É necessário informar um password'
                      )),
            
            
            
                        );
	

	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * hasMany associations
 *
 * @var array
 */
	public $hasMany = array(
		'Participante' => array(
			'className' => 'Participante',
			'foreignKey' => 'usuario_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);

}
