<?php
App::uses('AppModel', 'Model');
/**
 * Report Model
 *
 * @property Participante $Participante
 * @property Exercicio $Exercicio
 */
class Report extends AppModel {


	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * belongsTo associations
 *
 * @var array
 */
	public $belongsTo = array(
		'Participante' => array(
			'className' => 'Participante',
			'foreignKey' => 'participante_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Exercicio' => array(
			'className' => 'Exercicio',
			'foreignKey' => 'exercicio_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);
}
