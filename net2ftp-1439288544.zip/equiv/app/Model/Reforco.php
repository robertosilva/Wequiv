<?php
App::uses('AppModel', 'Model');
/**
 * Reforco Model
 *
 * @property Exercicio $Exercicio
 */
class Reforco extends AppModel {

         public $actsAs = array(
        'Upload.Upload' => array(
             'audio_format' => array (
                  'path' => '{ROOT}{DS}webroot{DS}files{DS}ref{DS}',
                        'fields' => array (
                                'dir'=>'path_audio'
                                 )) 
        )
    );

	//The Associations below have been created with all possible keys, those that are not needed can be removed

        public $displayField = 'name'; 
         
/**
 * hasMany associations
 *
 * @var array
 */
	public $hasMany = array(
		'Exercicio' => array(
			'className' => 'Exercicio',
			'foreignKey' => 'reforco_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);

}
