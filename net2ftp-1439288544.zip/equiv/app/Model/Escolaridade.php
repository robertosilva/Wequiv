<?php
App::uses('AppModel', 'Model');
/**
 * Escolaridade Model
 *
 */
class Escolaridade extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'name';

}
