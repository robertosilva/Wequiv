<?php
App::uses('AppModel', 'Model');
/**
 * EstimulosExercicio Model
 *
 * @property Exercicio $Exercicio
 * @property Estimulo $Estimulo
 */
class EstimulosExercicio extends AppModel {

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'tipo';


	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * belongsTo associations
 *
 * @var array
 */
	public $belongsTo = array(
		'Exercicio' => array(
			'className' => 'Exercicio',
			'foreignKey' => 'exercicio_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Estimulo' => array(
			'className' => 'Estimulo',
			'foreignKey' => 'estimulo_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);
}
