<?php
App::uses('AppModel', 'Model');
/**
 * Sessao Model
 *
 * @property Fase $Fase
 */
class Sessao extends AppModel {


	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * hasAndBelongsToMany associations
 *
 * @var array
 */
	public $hasAndBelongsToMany = array(
		'Fase' => array(
			'className' => 'Fase',
			'joinTable' => 'fases_sessaos',
			'foreignKey' => 'sessao_id',
			'associationForeignKey' => 'fase_id',
			'unique' => 'keepExisting',
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'finderQuery' => '',
		)
	);

}
