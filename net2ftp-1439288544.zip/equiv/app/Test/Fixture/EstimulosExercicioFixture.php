<?php
/**
 * EstimulosExercicioFixture
 *
 */
class EstimulosExercicioFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false, 'key' => 'primary'),
		'exercicio_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false, 'key' => 'index'),
		'estimulo_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false, 'key' => 'index'),
		'tipo' => array('type' => 'string', 'null' => true, 'default' => 'principal', 'length' => 45, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id', 'unique' => 1),
			'fk_exercicios_has_estimulos_estimulos1_idx' => array('column' => 'estimulo_id', 'unique' => 0),
			'fk_exercicios_has_estimulos_exercicios1_idx' => array('column' => 'exercicio_id', 'unique' => 0)
		),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'exercicio_id' => 1,
			'estimulo_id' => 1,
			'tipo' => 'Lorem ipsum dolor sit amet'
		),
	);

}
