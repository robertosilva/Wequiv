<?php
App::uses('Exercicio', 'Model');

/**
 * Exercicio Test Case
 *
 */
class ExercicioTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.exercicio',
		'app.estimulo',
		'app.estimulos_exercicio',
		'app.fase',
		'app.exercicios_fase',
		'app.sessao',
		'app.fases_sessao'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->Exercicio = ClassRegistry::init('Exercicio');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->Exercicio);

		parent::tearDown();
	}

}
