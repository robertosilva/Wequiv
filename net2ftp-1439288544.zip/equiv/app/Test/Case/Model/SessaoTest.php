<?php
App::uses('Sessao', 'Model');

/**
 * Sessao Test Case
 *
 */
class SessaoTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.sessao',
		'app.fase',
		'app.fases_sessao'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->Sessao = ClassRegistry::init('Sessao');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->Sessao);

		parent::tearDown();
	}

}
