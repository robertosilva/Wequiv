<?php
App::uses('Escolaridade', 'Model');

/**
 * Escolaridade Test Case
 *
 */
class EscolaridadeTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.escolaridade'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->Escolaridade = ClassRegistry::init('Escolaridade');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->Escolaridade);

		parent::tearDown();
	}

}
