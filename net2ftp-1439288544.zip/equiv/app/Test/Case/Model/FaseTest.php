<?php
App::uses('Fase', 'Model');

/**
 * Fase Test Case
 *
 */
class FaseTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.fase',
		'app.exercicio',
		'app.estimulo',
		'app.estimulos_exercicio',
		'app.exercicios_fase',
		'app.sessao',
		'app.fases_sessao'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->Fase = ClassRegistry::init('Fase');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->Fase);

		parent::tearDown();
	}

}
