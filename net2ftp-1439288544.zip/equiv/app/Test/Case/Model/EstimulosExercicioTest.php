<?php
App::uses('EstimulosExercicio', 'Model');

/**
 * EstimulosExercicio Test Case
 *
 */
class EstimulosExercicioTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.estimulos_exercicio',
		'app.exercicio',
		'app.estimulo',
		'app.fase',
		'app.exercicios_fase',
		'app.sessao',
		'app.fases_sessao'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->EstimulosExercicio = ClassRegistry::init('EstimulosExercicio');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->EstimulosExercicio);

		parent::tearDown();
	}

}
