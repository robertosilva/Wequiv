<?php
App::uses('Estimulo', 'Model');

/**
 * Estimulo Test Case
 *
 */
class EstimuloTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.estimulo',
		'app.exercicio',
		'app.estimulos_exercicio',
		'app.fase',
		'app.exercicios_fase',
		'app.sessao',
		'app.fases_sessao'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->Estimulo = ClassRegistry::init('Estimulo');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->Estimulo);

		parent::tearDown();
	}

}
