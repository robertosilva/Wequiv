<?php
App::uses('AppController', 'Controller');
/**
 * Estimulos Controller
 *
 * @property Estimulo $Estimulo
 * @property PaginatorComponent $Paginator
 */
class EstimulosController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Estimulo->recursive = 0;
		$this->set('estimulos', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Estimulo->exists($id)) {
			throw new NotFoundException(__('Estimulo inv�lido'));
		}
		$options = array('conditions' => array('Estimulo.' . $this->Estimulo->primaryKey => $id));
		$this->set('estimulo', $this->Estimulo->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->Estimulo->create();
                     if ($this->Estimulo->save($this->request->data)) {
                        $this->Session->setFlash(__('O estimulo foi salvo.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('O estimulo n�o foi salvo. Por favor, tente novamente.'));
			}
		}
		
		$this->set(compact('exercicios'));
                
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Estimulo->exists($id)) {
			throw new NotFoundException(__('Estimulo inv�lido'));
		}
		if ($this->request->is(array('post'))) {
                    	if ($this->Estimulo->save($this->request->data)) {
                            
				$this->Session->setFlash(__('O estimulo foi salvo.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('O estimulo n�o foi salvo. Por favor, tente novamente.'));
			}
		} else {
			$options = array('conditions' => array('Estimulo.' . $this->Estimulo->primaryKey => $id));
			$this->request->data = $this->Estimulo->find('first', $options);
		}
		//$exercicios = $this->Estimulo->Exercicio->find('list');
		//$this->set(compact('exercicios'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Estimulo->id = $id;
		if (!$this->Estimulo->exists()) {
			throw new NotFoundException(__('Estimulo inv�lido'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Estimulo->delete()) {
			$this->Session->setFlash(__('O estimulo foi exclu�do.'));
		} else {
			$this->Session->setFlash(__('O estimulo n�o foi exclu�do. Por favor, tente novamente.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
