<?php
App::uses('AppController', 'Controller');
/**
 * EstimulosExercicios Controller
 *
 * @property EstimulosExercicio $EstimulosExercicio
 * @property PaginatorComponent $Paginator
 */
class EstimulosExerciciosController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		//$this->Exercicio->recursive = 0;
		$this->set('exercicios', $this->Paginator->paginate('Exercicio'));
                $this->set('Reforcos',$this->EstimulosExercicio->Exercicio->Reforco->find('list'));
                $this->set('estimulosExercicios', $this->EstimulosExercicio->find('all'));
              
                
        }

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->EstimulosExercicio->exists($id)) {
			throw new NotFoundException(__('Exercício inválido.'));
		}
		$options = array('conditions' => array('EstimulosExercicio.' . $this->EstimulosExercicio->primaryKey => $id));
		$this->set('estimulosExercicio', $this->EstimulosExercicio->find('first', $options));
	}
/**
 * add method
 *
 * @return void
 *  */
        public function add() {
           
	if ($this->request->is('post')) {               
            $this->EstimulosExercicio->Exercicio->create();
               
	if ($this->EstimulosExercicio->Exercicio->save($this->request->data('Exercicio'))
                           && $this->_setSaveForm('EstimulosExercicio.estimulo_id',false,$id) 
                           ) {
                            
                             if ($this->_setSaveForm ('EstimulosExercicio_puzzle.estimulo_id',true,$id)){
                            
				$this->Session->setFlash(__('O exercício foi salvo.'));
				return $this->redirect(array('action' => 'index'));
                                
                             }else {
                                 
                                 $this->Session->setFlash(__('O exercício foi salvo sem puzzles.'));
				return $this->redirect(array('action' => 'index'));
                             }
                             
			}       else {
				$this->Session->setFlash(__('O exercício não foi salvo.'
                                        . ' Por favor, tente novamente.'));
                            }
                        }
		
		$exercicios = $this->EstimulosExercicio->Exercicio->find('list');
		$estimulos = $this->EstimulosExercicio->Estimulo->find('list');
                $this->set('reforcos',$this->EstimulosExercicio->Exercicio->Reforco->find('list'));
                         
              $this->set(compact('exercicios', 'estimulos'));
	}

 
/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->EstimulosExercicio->Exercicio->exists($id)) {
			throw new NotFoundException(__('Exercício inválido.'));
		}
		if ($this->request->is(array('post', 'put'))) {
                    debug($this->request->data('Exercicio'));
                //die();
			if ($this->EstimulosExercicio->Exercicio->save($this->request->data('Exercicio'))
                           && $this->_setSaveForm('EstimulosExercicio.estimulo_id',false,$id) 
                            && $this->_setSaveForm ('EstimulosExercicio_puzzle.estimulo_id',true,$id)) {
				$this->Session->setFlash(__('O exercício foi salvo.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('O exercício não foi salvo. Por favor, tente novamente.'));
			}
		} else {
                        $options = array('conditions' => array('Exercicio.' . $this->EstimulosExercicio->Exercicio->primaryKey => $id));
		        $this->request->data = $this->EstimulosExercicio->find('first', $options);
		
                
                                        
                                        
                }
              
		$exercicios = $this->EstimulosExercicio->Exercicio->find('list');
		$estimulos = $this->EstimulosExercicio->Estimulo->find('list');
                $this->set('reforcos',$this->EstimulosExercicio->Exercicio->Reforco->find('list'));
              	$this->set(compact('exercicios', 'estimulos'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
            
            
           
            
            
		$this->EstimulosExercicio->Exercicio->id = $id;
		if (!$this->EstimulosExercicio->Exercicio->exists()) {
			throw new NotFoundException(__('Exercício inválido.'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->EstimulosExercicio->deleteAll(array('EstimulosExercicio.exercicio_id' => $id ),false)
                     &&$this->EstimulosExercicio->Exercicio->delete()) {
                    
			$this->Session->setFlash(__('O exercício foi deletado.'));
		} else {
			$this->Session->setFlash(__('O exercício não foi deletado.'
                                        . ' Por favor, tente novamente.'));
		}
		return $this->redirect(array('action' => 'index'));
	}



       public function _setSaveForm($data,$noexists=true,$id=''){
            $true=0;
            $estimulosId = $this->request->data($data);
            $validAll= sizeof($estimulosId);
                    
            foreach( $estimulosId as $estimuloId){
            //    if($noexists) {                        
                $this->EstimulosExercicio->create();
             //   }else {
                    
            //        $this->EstimulosExercicio->deleteAll(array('EstimulosExercicio.exercicio_id' => $id ),false);
          //      }
                $this->EstimulosExercicio->set( array(
                                     'exercicio_id' => $this->EstimulosExercicio->Exercicio->id,
                                      'estimulo_id' => $estimuloId,
                                         ));
                      if ($data==='EstimulosExercicio_puzzle.estimulo_id')
                        $this->EstimulosExercicio->set('tipo','puzzle');    
                               
                       $this->EstimulosExercicio->save();
                       $true++;
                        
              }
             
                    return ($true==$validAll);
            
            
        }

}
