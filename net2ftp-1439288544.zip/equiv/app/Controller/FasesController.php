<?php
App::uses('AppController', 'Controller');
/**
 * Fases Controller
 *
 * @property Fase $Fase
 * @property PaginatorComponent $Paginator
 */
class FasesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Fase->recursive = 0;
		$this->set('fases', $this->Paginator->paginate());
                $this->set('exercicios',$this->Fase->Exercicio->find('all'));
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Fase->exists($id)) {
			throw new NotFoundException(__('Fase inválida'));
		}
		$options = array('conditions' => array('Fase.' . $this->Fase->primaryKey => $id));
		$this->set('fase', $this->Fase->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
            
            
            
		if ($this->request->is('post')) {
			$this->Fase->create();
                        
                        
                        
			if ($this->Fase->saveAll($this->request->data)) {
				$this->Session->setFlash(__('A fase foi salva.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('A fase não foi salva. Por favor, tente novamente.'));
			}
		}
		$exercicios = $this->Fase->Exercicio->find('list');
		
		$this->set(compact('exercicios'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Fase->exists($id)) {
			throw new NotFoundException(__('Fase inválida'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Fase->save($this->request->data)) {
				$this->Session->setFlash(__('A fase foi salva.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('A fase não foi salva. Por favor, tente novamente.'));
			}
		} else {
			$options = array('conditions' => array('Fase.' . $this->Fase->primaryKey => $id));
			$this->request->data = $this->Fase->find('first', $options);
		}
		$exercicios = $this->Fase->Exercicio->find('list');
		$sessaos = $this->Fase->Sessao->find('list');
		$this->set(compact('exercicios', 'sessaos'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Fase->id = $id;
		if (!$this->Fase->exists()) {
			throw new NotFoundException(__('Fase inválida'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Fase->delete()) {
			$this->Session->setFlash(__('A fase foi excluída.'));
		} else {
			$this->Session->setFlash(__('A fase não foi excluída. Por favor, tente novamente.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
