<?php
App::uses('AppController', 'Controller');



/**
 * Usuarios Controller
 *
 * @property Usuario $Usuario
 * @property PaginatorComponent $Paginator
 */
class UsuariosController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');
        public $helpers = array('Js' => array('Jquery'));
        
        
  public function beforeFilter() {
    parent::beforeFilter();
    // Allow users to register and logout.
    $this->Auth->allow('logout');
}
        
        
        

   public function login() {
        $this->layout = 'notlogged';
        if($this->request->is('post')){
//            print_r($this->request->data);
           
            
            debug(AuthComponent::password($this->data[$this->alias]['password']));
            
            
            if ($this->Auth->login()){
               return $this->redirect($this->Auth->redirectUrl());
            }
            $this->Session->setFlash('Nome de usuário e/ou senha inválido(s). '
                   . 'Por favor tente novamente');

        }

	}
        
      public function logout(){
         
          
          $this->redirect($this->Auth->logout());
          
      }
        
        
        
        
        
        /**
 * index method
 *
 * @return void
 */
        
        
	public function listUser() {
		$this->Usuario->recursive = 0;
                 $this->Paginator->settings = array(
                 'conditions' => array('Usuario.usuario_id' => $this->Auth->user('id'))
       
    );
		$this->set('usuarios', $this->Paginator->paginate());
	}
        
        
        public function index() {
	//only renders the view to select proper user -> participante or pesquisador.	
	}
        
 


/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
//	public function view($id = null) {
//		if (!$this->Usuario->exists($id)) {
//			throw new NotFoundException(__('Pesquisador Inválido'));
//		}
//		$options = array('conditions' => array('Usuario.' . $this->Usuario->primaryKey => $id));
//		$this->set('usuario', $this->Usuario->find('first', $options));
//	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
                    
                      $this->request->data['Usuario']['usuario_id'] = $this->Auth->user('id');
                  
			$this->Usuario->create();
			if ($this->Usuario->save($this->request->data)) {
				$this->Session->setFlash(__('O pesquisador foi salvo com sucesso.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('O pesquisador não pôde ser salvo. Tente novamente.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Usuario->exists($id)) {
			throw new NotFoundException(__('Pesquisador Inválido'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Usuario->save($this->request->data)) {
				$this->Session->setFlash(__('O pesquisador foi salvo com sucesso.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('O pesquisador não pôde ser salvo. Tente novamente.'));
			}
		} else {
			$options = array('conditions' => array('Usuario.' . $this->Usuario->primaryKey => $id));
			$this->request->data = $this->Usuario->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Usuario->id = $id;
		if (!$this->Usuario->exists()) {
			throw new NotFoundException(__('Participante inválido!'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Usuario->delete()) {
			$this->Session->setFlash(__('O pesquisador foi deletado.'));
		} else {
			$this->Session->setFlash(__('O pesquisador não pôde ser deletado. Por favor,tente novamente.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
