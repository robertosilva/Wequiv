<?php
App::uses('AppController', 'Controller');
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of RealizaController
 *
 * @author Iwá
 */


class RealizasController extends AppController {
      //put your code here
  
    public $components = array('Paginator','RequestHandler');
    public $uses = array ('EstimulosExercicio','Fase','Sessao','Usuario','Participante','Report');
 

    public function salvar (){
    $this->autoRender = false;
   
     
     if ($this->request->is('ajax')) {
            
            
          $report = json_decode ($this->request->data,true);
          $this->Report->create();
		if ($this->Report->saveAll($report)) {
                            
                            
				//$this->Session->setFlash(__('The report has been saved.'));
				//return $this->redirect(array('action' => 'index'));
                                return json_encode(array('saveSuccess' => true));
                            
			} else {
                            return json_encode(array('saveSuccess' => false));
				//$this->Session->setFlash(__('The report could not be saved. Please, try again.'));
			}
     
          
        }

        
    }
    
    
    public function _typeExerc($tipo){
        
        if ($tipo ==='1'){
         return $this->EstimulosExercicio->Exercicio->find('all',
              array( 'conditions' => array(
            'OR NOT'=>array('Exercicio.tipo_estimulo' => 'texto',
                         'Exercicio.tipo_puzzle' => 'texto'
            ))));
        
        } else if($tipo ==='2'){
             
          $anagramas = $this->EstimulosExercicio->Exercicio->find('all',
           array( 'conditions' => array('Exercicio.tipo_puzzle' => 'texto',              
                                        'Exercicio.tipo_estimulo' => 'texto' 
               )));
        
        return $anagramas;
         }
       
         else if($tipo ==='3'){  $fases = $this->Fase->find('all'); 
        
        return $fases;
         }
        else if($tipo ==='4'){  $sessoes = $this->Sessao->find('all');
         
        
        return $sessoes;
         } 
       }
    
    public function fasesessao($tipo){
        
        
                    $this->Paginator->settings = array(
                 'conditions' => array('Participante.usuario_id' => $this->Auth->user('id'))
       
    );
        
        
         $this->set('participantes', $this->Paginator->paginate('Participante'));
        $this->set('fase_sessaos', $this->_typeExerc($tipo));
        $this->set('faseexercs',$this->Fase->find('all'));
        if ($tipo==='3')
        $this->set('faseorsessao','Fase');
        else if ($tipo==='4')
         $this->set('faseorsessao','Sessao');
        
        if ($this->request->is('post')) {
           
       
         list ($response, $arrayFindExerc, $arrayFindPart) = $this->_formatExerc($this->request->data,'fs');
       
           
        if ($response === 1 ) {
                
		$this->Session->setFlash(__('Por favor escolha apenas um participante.'));
                $this->request->data ='';
 
        }
       else if ($response === 2){ 
               
                $this->Session->setFlash(__('É necessário informar uma fase.'));
             } 
            else if ($response ===3){
                
                
             $this->Session->write('findExcond', $arrayFindExerc);  
              $this->Session->write('findPartcond', $arrayFindPart);  
              $this->redirect(array('action' => 'realizar'));
                
//            $this->realizar($arrayFindExerc, $arrayFindPart);
     
                }
    
     }
        
    }
    
    public function index ($tipo){
     $this->Paginator->settings = array(
                 'conditions' => array('Participante.usuario_id' => $this->Auth->user('id'))
       
    );
     $this->set('participantes', $this->Paginator->paginate('Participante'));
    // $this->set('exercicios', $this->paginate($Exercicios));
    $this->set('Exercicios',  $this->_typeExerc($tipo) );
    $this->set('Reforcos',$this->EstimulosExercicio->Exercicio->Reforco->find('list'));
    
    // Verifica participante e exercicios/fases/sessões selecionados //
     
     if ($this->request->is('post')) {
      
         list ($response, $arrayFindExerc, $arrayFindPart) = $this->_formatExerc($this->request->data);
      
        if ($response === 1 ) {
                
		$this->Session->setFlash(__('Por favor escolha apenas um participante.'));
                $this->request->data ='';
//                 debug($response);
//        die();   
        }
       else if ($response === 2){ 
               
                $this->Session->setFlash(__('É necessário informar um exercício.'));
             } 
            else if ($response ===3){
                
                
              $this->Session->write('findExcond', $arrayFindExerc);  
              $this->Session->write('findPartcond', $arrayFindPart);  
              $this->redirect(array('action' => 'realizar'));
                 //return $this->realizar($arrayFindExerc, $arrayFindPart);
                    
                }
    
     } }
     
   
          
  public function _formatExerc($datas,$controller='as'){
         $valid_partic=0;
         $valid_exerc =0;
         $arrayFindExerc=[];
         $arrayFindPart=[];
         $arrayFindFase=[];
         
        foreach ($datas as $data) {
            //Preenche a variavel arrayFindFase para setar corretamente os exercicios linkados a (Fase)
          foreach ($data as $key=>$partexer){
            if (strpos($key,'Fase')!== false || strpos($key,'Sessao')!== false){
                   
              $arrayFindFase[]=$partexer;}}
            
            //Percorre o array e seta os exercicios devidamente.
            foreach ($data as $key=>$partexer){
              
               if ($partexer!=='' && $partexer!=='0'){
                if (strpos($key,'participante')!== false){
                     
                   $valid_partic++;
                   $arrayFindPart['Participante.id']=$partexer;
                }else if (strpos($key,'Fase')!== false || strpos($key,'Sessao')!== false){
                   
                    $valid_exerc++;
                                        
                } else if (strpos($key,'exercicio')!== false){
                      
                    if($controller!=='fs'){
                      $valid_exerc++;
                      $arrayFindExerc[]=$partexer;
                      
                    }
                   else if ($controller==='fs'){
                      
                        foreach ($arrayFindFase as $fase){
                       
                             if ((strpos($key,'fs'.$fase )!== false)) { 
                                 
                                     $arrayFindExerc[]=$partexer;
                             
                                     
                             }
                        }
                        
                    }
                      
                }            
               
                }}}
                
                if ($valid_partic!==1 ) return array (1,$arrayFindExerc,$arrayFindPart);
                else if ($valid_exerc ===0)  return array (2,$arrayFindExerc,$arrayFindPart);
                else return array (3,$arrayFindExerc,$arrayFindPart);
                
  }        
          
 

 public function realizar() {    
   
    
    
$findPartcond = $this->Session->read('findPartcond');
$findExcond = $this->Session->read('findExcond');

     
     $this->EstimulosExercicio->Exercicio->recursive = -1;
     
        $options['conditions'] = array('Exercicio.id' => array_unique ($findExcond ));
        $options['joins'] = array(array('table' => 'estimulos_exercicios', 'alias' => 'EstimulosExercicio',
            'type' => 'inner','conditions' => array( 'Exercicio.id = EstimulosExercicio.exercicio_id')),
                    array('table' => 'reforcos', 'alias' => 'Reforco',
            'type' => 'inner','conditions' => array( 'Exercicio.reforco_id = Reforco.id')),
            array('table' => 'estimulos', 'alias' => 'Estimulo',
                       'type' => 'inner','conditions' => array('EstimulosExercicio.estimulo_id = Estimulo.id'
                                )));

       $options['fields'] = array('Exercicio.id', 'Exercicio.sigla','Exercicio.tipo_estimulo','Exercicio.tipo_puzzle',
           'Exercicio.reforco_id','Exercicio.qtd_per_estimulo','Exercicio.percent_acerto','Exercicio.silabas_puzzle',
           'Estimulo.id', 'Estimulo.name','Estimulo.formacao_componente','Estimulo.path_image','Estimulo.image_format',
           'Estimulo.path_audio','Estimulo.audio_format','EstimulosExercicio.tipo',
           'Reforco.path_audio','Reforco.audio_format' ); 

         $this->set('exercicio', $this->EstimulosExercicio->Exercicio->find('all',$options));


                  if (!$this->Participante->exists($findPartcond['Participante.id'])) {
                           throw new NotFoundException(__('Participante inválido'));}
                                                 
                    $options = array('conditions' => array('Participante.' .
                    $this->Participante->primaryKey => $findPartcond['Participante.id']));
                    $this->set('participante', $this->Participante->find('first', $options));
                    $this->set('orderofExec',$findExcond);
                   // $this -> render('realizar');
                  
                   if ($this->request->is('post')) {
            
            debug($this->request->data);
            
        }
                    
                    
                  }
                 
                   
                   
                  }
