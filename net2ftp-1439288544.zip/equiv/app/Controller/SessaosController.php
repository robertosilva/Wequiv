<?php
App::uses('AppController', 'Controller');
/**
 * Sessaos Controller
 *
 * @property Sessao $Sessao
 * @property PaginatorComponent $Paginator
 */
class SessaosController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Sessao->recursive = 0;
		$this->set('sessaos', $this->Paginator->paginate());
                $this->set('fases',$this->Sessao->Fase->find('all'));
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Sessao->exists($id)) {
			throw new NotFoundException(__('Sessão inválida.'));
		}
		$options = array('conditions' => array('Sessao.' . $this->Sessao->primaryKey => $id));
		$this->set('sessao', $this->Sessao->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->Sessao->create();
			if ($this->Sessao->save($this->request->data)) {
				$this->Session->setFlash(__('A sessão foi salva.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('A sessão não foi salva. Por favor, tente novamente.'));
			}
		}
		$fases = $this->Sessao->Fase->find('list');
		$this->set(compact('fases'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Sessao->exists($id)) {
			throw new NotFoundException(__('Sessão inválida.'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Sessao->save($this->request->data)) {
				$this->Session->setFlash(__('A sessão foi salva.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('A sessão não foi salva. Por favor, tente novamente.'));
			}
		} else {
			$options = array('conditions' => array('Sessao.'.$this->Sessao->primaryKey => $id));
			$this->request->data = $this->Sessao->find('first', $options);
                      
		}
		$fases = $this->Sessao->Fase->find('list');
		$this->set(compact('fases'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Sessao->id = $id;
		if (!$this->Sessao->exists()) {
			throw new NotFoundException(__('Sessão inválida.'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Sessao->delete()) {
			$this->Session->setFlash(__('A sessão foi excluída.'));
		} else {
			$this->Session->setFlash(__('A sessão não foi excluída. Por favor, tente novamente.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
