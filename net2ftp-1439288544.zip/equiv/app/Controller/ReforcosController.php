<?php
App::uses('AppController', 'Controller');
/**
 * Reforcos Controller
 *
 * @property Reforco $Reforco
 * @property PaginatorComponent $Paginator
 */
class ReforcosController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Reforco->recursive = 0;
		$this->set('reforcos', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Reforco->exists($id)) {
			throw new NotFoundException(__('Refoço inválido.'));
		}
		$options = array('conditions' => array('Reforco.' . $this->Reforco->primaryKey => $id));
		$this->set('reforco', $this->Reforco->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->Reforco->create();
			if ($this->Reforco->save($this->request->data)) {
				$this->Session->setFlash(__('O reforço foi salvo.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('O reforço não foi salvo. Por favor, tente novamente.'));
			}
		}
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Reforco->exists($id)) {
			throw new NotFoundException(__('Refoço inválido.'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Reforco->save($this->request->data)) {
				$this->Session->setFlash(__('O reforço foi salvo.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('O reforço não foi salvo. Por favor, tente novamente.'));
			}
		} else {
			$options = array('conditions' => array('Reforco.' . $this->Reforco->primaryKey => $id));
			$this->request->data = $this->Reforco->find('first', $options);
		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Reforco->id = $id;
		if (!$this->Reforco->exists()) {
			throw new NotFoundException(__('Refoço inválido.'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Reforco->delete()) {
			$this->Session->setFlash(__('O reforço foi excluído.'));
		} else {
			$this->Session->setFlash(__('O reforço não foi excluído. Por favor, tente novamente.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
