<?php
App::uses('AppController', 'Controller');
/**
 * Reports Controller
 *
 * @property Report $Report
 * @property PaginatorComponent $Paginator
 */
class ReportsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');
         public $uses = array ('Report','Participante');    
/**
 * index method
 *
 * @return void
 */
	public function index() {
            
            $req_participa = $this->Session->read('requestedparticipantes');
           
		$this->Report->recursive = 0;
                 $this->Paginator->settings=array(
              'limit'=>32,
               'conditions'=> array ('Report.participante_id'=>$req_participa)
       );
		$this->set('reports', $this->Paginator->paginate('Report'));
	}
        
        

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Report->exists($id)) {
			throw new NotFoundException(__('Relatório inválido'));
		}
		$options = array('conditions' => array('Report.' . $this->Report->primaryKey => $id));
		$this->set('reports', $this->Report->find('first', $options));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
        
    public function filter_report(){
      $arrayofId;   
      $this->Paginator->settings = array(
                 'conditions' => array('Participante.usuario_id' => $this->Auth->user('id'))
       
    );
         $this->set('participantes', $this->Paginator->paginate('Participante'));
      
       
             
        if ($this->request->is('post')) {
           
        if (empty($this->request->data)) {
                
		$this->Session->setFlash(__('Por favor escolha  um participante.'));
                
 
        }  else {            
            foreach ($this->request->data as $data) {
             foreach ($data as $part){
                 
                  $arrayofId[]=$part;
             
            }}
            
           
             $this->Session->write('requestedparticipantes',$arrayofId );  
             $this->redirect(array('action' => 'index'));
                
//            $this->realizar($arrayFindExerc, $arrayFindPart);
     
                }
    
     }      
     } 
        
        
        
        //use delete All // to delete where the exercicio is choosen.
	public function delete($id = null) {
		$this->Report->id = $id;
		if (!$this->Report->exists()) {
			throw new NotFoundException(__('Relatório inválido'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Report->delete()) {
			$this->Session->setFlash(__('O relatório foi deletado.'));
		} else {
			$this->Session->setFlash(__('O relatório não foi deletado.'
                                        . ' Por favor, tente novamente.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

        public function deleteAll($id=null,$data=null)  {
	            
           
            $this->Report->Exercicio->id = $id;
                   
                   
		if (!$this->Report->Exercicio->exists()) {
			throw new NotFoundException(__('Relatório inválido.'));
		}
		$this->request->allowMethod('post', 'delete');
                
		if ($this->Report->deleteAll(array('Report.exercicio_id' => $id, 'Report.created'=>urldecode ($data)),false)) {
                 
                    $this->Session->setFlash(__('O relatório foi deletado.'));
		} else {
			$this->Session->setFlash(__('O relatório não foi deletado.'
                                        . ' Por favor, tente novamente.'));
		}
		return $this->redirect(array('action' => 'index'));
	}

        
        
        
        
        
        
        
        
        
        
        
        
                }
