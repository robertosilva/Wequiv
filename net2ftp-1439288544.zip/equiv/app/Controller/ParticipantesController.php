<?php
App::uses('AppController', 'Controller');
/**
 * Participantes Controller
 *
 * @property Participante $Participante
 * @property PaginatorComponent $Paginator
 */
class ParticipantesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Participante->recursive = 0;
                
                $this->Paginator->settings = array(
                 'conditions' => array('Participante.usuario_id' => $this->Auth->user('id'))
       
    );
		$this->set('participantes', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 
	public function view($id = null) {
		if (!$this->Participante->exists($id)) {
			throw new NotFoundException(__('Participante inválido!'));
		}
		$options = array('conditions' => array('Participante.' . $this->Participante->primaryKey => $id));
		$this->set('participante', $this->Participante->find('first', $options));
	}
*/
/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
                    
                     $this->request->data['Participante']['usuario_id'] = $this->Auth->user('id');
                    
			$this->Participante->create();
			if ($this->Participante->save($this->request->data)) {
				$this->Session->setFlash(__('O participante foi salvo com sucesso.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('O participante não pôde ser salvo. Tente novamente.'));
			}
		}
		
                //escolaridade 1:n
                $this->set('escolaridades',$this->Participante->Escolaridade->find('list'));
                //sexo 1:n
                $this->set('sexos',$this->Participante->Sexo->find('list'));
                //estado  1:n
                $this->set('estados',$this->Participante->Estado->find('list'));
                //set usuario
                $this->set('usuarios',$this->Participante->Usuario->find('list'));
               
                    
        }
/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Participante->exists($id)) {
			throw new NotFoundException(__('Participante inválido!'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Participante->save($this->request->data)) {
				$this->Session->setFlash(__('O participante foi salvo com sucesso.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('O participante não pôde ser salvo. Tente novamente.'));
			}
		} else {
			$options = array('conditions' => array('Participante.' . $this->Participante->primaryKey => $id));
			$this->request->data = $this->Participante->find('first', $options);
		}
		$usuarios = $this->Participante->Usuario->find('list');
		$this->set(compact('usuarios'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Participante->id = $id;
		if (!$this->Participante->exists()) {
			throw new NotFoundException(__('Participante inválido!'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Participante->delete()) {
			$this->Session->setFlash(__('O participante foi deletado.'));
		} else {
			$this->Session->setFlash(__('O participante não pôde ser deletado. Por favor,tente novamente.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
