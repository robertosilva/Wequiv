<?php
App::uses('AppController', 'Controller');
/**
 * Exercicios Controller
 *
 * @property Exercicio $Exercicio
 * @property PaginatorComponent $Paginator
 */
class ExerciciosController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Exercicio->recursive = 0;
		$this->set('exercicios', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Exercicio->exists($id)) {
			throw new NotFoundException(__('Invalid exercicio'));
		}
		$options = array('conditions' => array('Exercicio.' . $this->Exercicio->primaryKey => $id));
		$this->set('exercicio', $this->Exercicio->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
                    
                     debug ($this->request->data);
                       die();
                        
			$this->Exercicio->create();
			if ($this->Exercicio->saveAssociated($this->request->data)) {
				$this->Session->setFlash(__('The exercicio has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The exercicio could not be saved. Please, try again.'));
			}
		}
                $estimulos = $this->Exercicio->EstimulosExercicio->Estimulo->find('list');
		
		$this->set(compact('estimulos'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Exercicio->exists($id)) {
			throw new NotFoundException(__('Invalid exercicio'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Exercicio->save($this->request->data)) {
				$this->Session->setFlash(__('The exercicio has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The exercicio could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Exercicio.' . $this->Exercicio->primaryKey => $id));
			$this->request->data = $this->Exercicio->find('first', $options);
		}
		$fases = $this->Exercicio->Fase->find('list');
		$this->set(compact('fases'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Exercicio->id = $id;
		if (!$this->Exercicio->exists()) {
			throw new NotFoundException(__('Invalid exercicio'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Exercicio->delete()) {
			$this->Session->setFlash(__('The exercicio has been deleted.'));
		} else {
			$this->Session->setFlash(__('The exercicio could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
