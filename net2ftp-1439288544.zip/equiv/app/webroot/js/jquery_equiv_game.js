





/* global reportAll */

//verificar tipos de estimulo e puzzle para gerar corretamente o game.
inc=0;
function init2() {

id_estimulo=[],id_puzzle=[],pathAud=[],pathImg=[],pathImgP=[],name_estimulo=[];
name_puzzle=[], tipo_estimulo='', tipo_puzzle='',pos=[],src_estimulo='';src_puzzle='';qtd_acerto = [],
numtotalEstimulos=0;correctChoices=0, audioElement=[],formacaocomp_puzzle=[],formacaocomp_estimulo=[],
acertou=0,nextsearch=[],reforco='',resultado='',exercicio_id='',time=0,tentativa=1;

 
for (var i=0;i<window.app.exercicios.length;i++){
 
    
   nextsearch= window.app.orderofExec;
      
                         

if (window.app.exercicios[i].Exercicio.id === nextsearch[inc]){
	exercicio_id = window.app.exercicios[i].Exercicio.id;
	tipo_estimulo = window.app.exercicios[i].Exercicio.tipo_estimulo; 
	tipo_puzzle = window.app.exercicios[i].Exercicio.tipo_puzzle;
	qtd_puzzles = window.app.exercicios[i].Exercicio.silabas_puzzle;
	qtd_rodadas_estimulos= parseInt(window.app.exercicios[i].Exercicio.qtd_per_estimulo)*
               parseInt(window.app.exercicios[i].Exercicio.percent_acerto)/100;
     // tipo_estimulo='texto';
     // tipo_puzzle ='texto';
     //  
        
	if (window.app.exercicios[i].EstimulosExercicio.tipo==='principal'){
	id_estimulo.push(window.app.exercicios[i].Estimulo.id);
        // ex id_estimulo = [15,13,10,9];
	name_estimulo.push(window.app.exercicios[i].Estimulo.name);
        formacaocomp_estimulo.push((window.app.exercicios[i].Estimulo.formacao_componente.split("+")));
        numtotalEstimulos++;
        pathAud.push(window.app.exercicios[i].Estimulo.path_audio+'/'+window.app.exercicios[i].Estimulo.audio_format);
      	pathImg.push(window.app.exercicios[i].Estimulo.path_image+'/'+window.app.exercicios[i].Estimulo.image_format);
        
	}
        id_puzzle.push (window.app.exercicios[i].Estimulo.id);
        // ex id_puzzle  = [15,13,10,9,120,1,3,4];
        formacaocomp_puzzle.push((window.app.exercicios[i].Estimulo.formacao_componente).split("+"));
       	
	pathImgP.push(window.app.exercicios[i].Estimulo.path_image+'/'+window.app.exercicios[i].Estimulo.image_format);
        name_puzzle.push(window.app.exercicios[i].Estimulo.name);
	reforco = window.app.exercicios[i].Reforco.path_audio+'/'+window.app.exercicios[i].Reforco.audio_format;

                    }
                    
             }


if (tipo_estimulo==='texto' && tipo_puzzle==='texto'){
	src_estimulo= name_estimulo;
	src_puzzle = name_puzzle;
       
}
else if (tipo_estimulo==='audio' && tipo_puzzle==='texto'){
	src_estimulo = pathAud;
	src_puzzle = name_puzzle;
}
else if (tipo_estimulo==='audio' && tipo_puzzle==='imagem'){
	src_estimulo= pathAud;
	src_puzzle = pathImgP; 
}
else if (tipo_estimulo==='imagem' && tipo_puzzle==='texto'){
	src_estimulo= pathImg.slice();; 
	src_puzzle = name_puzzle;
}
else if (tipo_estimulo==='imagem' && tipo_puzzle==='imagem'){ //covered
	src_estimulo= pathImg.slice();; 
	src_puzzle = pathImgP; 
}

else if (tipo_estimulo==='texto' && tipo_puzzle==='imagem'){
	src_estimulo= name_estimulo;
	src_puzzle = pathImgP; 
}


//id_tmp= id_estimulo.slice();
//Array.prototype.push.apply(id_tmp,id_puzzle);
//id_puzzle = id_tmp.slice();

src_estimulo = src_estimulo.splice(0,id_estimulo.length);
    typeReforco();

}


$(document).ready(function() { 
 reportAll=[];
 alert("Por favor clique em OK para iniciar");
 //Iniciando o exercício. Por favor sente-se num local adequado e esteja relaxado para iniciar a atividade!\n\
//Quando estiver pronto clique em OK");
 
 $(init2);
 $(init);


 
});

function init() {
    
  if(window.location.hash!=='') {
        anchorArr = window.location.hash;
        anchorArr = anchorArr.split('#');
        curNum = anchorArr[1];
    } 

  // Hide the success message
  $('#successMessage').hide();
  $('#successMessage').css( {
    left: '580px',
    top: '250px',
    width: 0,
    height: 0
  } );

  // Reset the game
  $('#slot_puzzle_anagrama').attr('id','slot_puzzle');
  $('#slot_estimulos_anagrama').attr('id','slot_estimulos');
  putCards = 0;
  numPut=0;
  $('#slot_puzzle').html( '' );
  $('#slot_estimulos').html( '' );
  $('#navZX').remove();
    
  // Preenche o array position (pos) do quebra cabeça (puzzle) e certifica-se de inserir o estimulo sobrescrevendo uma posição.

					//qtd_puzzles = (entre 2-6);
choosen_estimulo_index = Math.floor(Math.random() * id_estimulo.length);
choosen_pos_index = Math.floor(Math.random() * qtd_puzzles);

    

 var id_puzzle_temp = id_puzzle.slice();
for (i=0;i<qtd_puzzles;i++) // qtd_puzzle -> informa quantidade de puzzles que vão aparecer no html.
{
   
    push_pop_id = Math.floor(Math.random() * id_puzzle_temp.length);
    pos[i] = id_puzzle_temp [push_pop_id]; //ex pos[0]=10;

    id_puzzle_temp.splice(push_pop_id,1); //remove id sorteado do array id_puzzle;
    
   if (pos[i] === id_estimulo [choosen_estimulo_index]){
              choosen_pos_index = i;
   }
    
    }
   
    pos[choosen_pos_index]= id_estimulo [choosen_estimulo_index];
    
    typeGame();
    time= new Date().getTime();




    

  
    
      }

//::: jogando ::: ///

//drop-drag-silabas
function handleSyllableDrop(event, ui){
   var stopinit=false; 
    
  var cardName = $(this).data( 'name' );  //escolheu
  var cardNumber = $(this).data( 'number' );
  var fNameCard = $(this).data( 'fullname' );
  
  var slotName = ui.draggable.data( 'name' );  //modelo/estimulo
  var slotNumber = ui.draggable.data( 'number' );  //modelo/estimulo
  var fNameSlot = ui.draggable.data( 'fullname' ); 
  var sizeofsylab = formacaocomp_estimulo[choosen_estimulo_index].length;
console.log(slotName);
console.log(cardName);

  // If the card was dropped to the correct slot,
  // change the card colour, position it directly
  // on top of the slot, and prevent it being dragged
  // again
     
    ui.draggable.draggable( 'disable' );
    ui.draggable.css( 'background-color','#ccc' );
    $(this).droppable( 'disable' );
    ui.draggable.position( { of: $(this), my: 'left top', at: 'left top' } );
     ui.draggable.draggable( 'option', 'revert',false );
 
 
    time = new Date().getTime() - time;
    if (slotName===cardName) { 
     
        putCards++;
        resultado = "ACERTOU";
        $(reportSave(resultado,cardNumber,cardName,slotNumber,slotName,fNameCard,fNameSlot,'anagrama'));
         time = new Date().getTime();
    }
         
 console.log(putCards);
 if ( putCards===sizeofsylab ) {
    audioElement.pause();
    audioElement.currentTime = 0;
    audioElement.play();
      resultado = "ACERTOU";
    
      !qtd_acerto[ choosen_estimulo_index]?qtd_acerto[choosen_estimulo_index]=1:qtd_acerto[choosen_estimulo_index]++;
      console.log(qtd_acerto);
      
     if( qtd_acerto[choosen_estimulo_index]===qtd_rodadas_estimulos){
         
       console.log("deletando");
        id_estimulo.splice(choosen_estimulo_index,1);
        src_estimulo.splice(choosen_estimulo_index,1);
        qtd_acerto.splice(choosen_estimulo_index,1);
         formacaocomp_estimulo.splice(choosen_estimulo_index,1);
        //// --->>>>> submit to MODEL REPORT  
       console.log(id_estimulo);
    
     
        }
        
      correctChoices++;
} else if ( slotName!==cardName ){
    console.log('errou');
    resultado = "ERROU";
   $(reportSave(resultado,cardNumber,cardName,slotNumber,slotName,fNameCard,fNameSlot,'anagrama'));
  
   time = new Date().getTime();
}
  
if (correctChoices===qtd_rodadas_estimulos*numtotalEstimulos){
    inc++;
    console.log ('Exericicio '+nextsearch[inc]);
   
   if (typeof nextsearch[inc]!=='undefined'){
             $(init2);
     }
     else {
         console.log('GAME O V  E  R  R R R R R ');
           $(reportSend());
         stopinit = true;
         
     }
    
    
}
numPut++;
if(numPut===sizeofsylab){
    setTimeout( function() {
        if (!stopinit) $(init);
        
    }, 2000);
     
} 

}


function reportSend(){
     
   $.ajax({
        type: 'POST',
        url: 'salvar',
        dataType: 'json',
        data:{data: JSON.stringify(reportAll)}, 
         
        success: function(data){
           if(data.saveSuccess === true){
            
           
            console.log ('done');
            alert("Atividade finalizada. Relatório salvo com sucesso. Obrigado!");
            
                
            }else if(data.saveSuccess === false){
            
           
            console.log ('done');
            alert('Um erro ocorreu. Relatório não salvo. Por favor contate o administrador');
            
                
            } 
            // the redirect
            window.location = '/equiv/';
        
        
        },
            error: function()
            {
                alert('Ocorreu um erro no servidor.Por favor contate o administrador');
                window.location = '/equiv/';  // the redirect
            } 
 
    });
  
}


function reportSave(resultado,cardNumber,cardName,slotNumber,slotName,fNameCard,fNameSlot,type){
   var reportdata={};
    type = typeof type !== 'undefined' ? type : '';
  fNameCard = typeof fNameCard !== 'undefined' ? fNameCard : '';
  fNameSlot = typeof fNameSlot !== 'undefined' ? fNameSlot : '';
  reportdata['participante_id'] = window.app.participante.Participante.id;
  reportdata['exercicio_id'] =  exercicio_id; 
  reportdata['tentativa']= tentativa;
  reportdata['modelo_id']= cardNumber ;
  reportdata['modelo'] = cardName; //escolhendo nome ao invés do ID
  reportdata['tipo_modelo']=  tipo_estimulo;
  reportdata['escolheu_id']=  slotNumber;
  reportdata['escolheu']= slotName; //escolhendo nome ao invés do ID
  reportdata['tipo_escolheu']= tipo_puzzle;
  reportdata['resultado'] =  resultado;
  reportdata ['time']=Math.floor(time/100)/10;
  if (type !=='anagrama'){
  reportdata ['position01']= $('#pos1').data( 'name' ); 
  reportdata ['position02']= $('#pos2').data( 'name' ); 
  reportdata ['position03']= $('#pos3').data( 'name' ); 
  reportdata ['position04']= $('#pos4').data( 'name' ); 
  reportdata ['position05']= $('#pos5').data( 'name' ); 
  reportdata ['position06']= $('#pos6').data( 'name' ); 
  }
  else if(type==='anagrama'){
   reportdata['name_modelo'] = fNameCard;
   reportdata['name_escolheu']=fNameSlot;
  }
  
   console.log ('--------------');
   console.log (reportdata);
   reportAll.push(reportdata);
   console.log ('--------------');
   //console.log (reportAll);
   tentativa++;
    
}
//click image
//qtd_acerto é um array do tipo [0,0,0,0,0...] para verificar se o estimulo foi escolhido corretamente N vezes
function handleClickImage() {
  
  var stopinit=false;
  var slotNumber = $(this).data( 'number' );
  var slotName = $(this).data( 'name' ); //report fase 3
  var cardNumber =  $('#slot_estimulo').length ? $('#slot_estimulo').data( 'number' ):$('#slot_estimulos').data( 'number' );
  var cardName = $('#slot_estimulo').length ? $('#slot_estimulo').data( 'name' ):$('#slot_estimulos').data( 'name' );
  console.log(slotNumber);
    console.log(slotName);

time = new Date().getTime() - time;
if ( slotNumber === cardNumber ) {

    audioElement.pause();
    audioElement.currentTime = 0;
    audioElement.play();
     
      resultado = "ACERTOU";
       $(reportSave(resultado,cardNumber,cardName,slotNumber,slotName));
      !qtd_acerto[ choosen_estimulo_index]?qtd_acerto[choosen_estimulo_index]=1:qtd_acerto[choosen_estimulo_index]++;
      console.log(qtd_acerto);
      
     if( qtd_acerto[choosen_estimulo_index]===qtd_rodadas_estimulos){
         
       console.log("deletando");
        id_estimulo.splice(choosen_estimulo_index,1);
        src_estimulo.splice(choosen_estimulo_index,1);
        qtd_acerto.splice(choosen_estimulo_index,1);
       
        //// --->>>>> submit to MODEL REPORT  
       console.log(id_estimulo);
     
        }
        
      correctChoices++;
} else if ( slotNumber !== cardNumber ){
    console.log('errou');
    resultado = "ERROU";
    $(reportSave(resultado,cardNumber,cardName,slotNumber,slotName));
   
}
  
if (correctChoices===qtd_rodadas_estimulos*numtotalEstimulos){
     inc++;
    console.log ('Exericicio '+(nextsearch[inc+1]));
   if (typeof nextsearch[inc]!=='undefined'){
             $(init2);
     }
     else {
         console.log('GAME O V  E  R  R R R R R ');
           $(reportSend());
         stopinit = true;
         
     }
 }
setTimeout(
  function() 
  {
    if (!stopinit) $(init);  
  }, 2000);

 

//
// if ( correctCards == 0 ) {
//    var buttonText = 'Go to Next Level';
//    var goLeft = $(window).width(); 
//    var goTop = $(window).height();
//    goLeft = (goLeft-400)/2;
//    goTop = (goTop-300)/2;
//    goLeft = goLeft+'px';
//    goTop = goTop+'px';
//    $('#successMessage').show();
//    $('#successText').text("Level "+curNum+" done!");
//    if(curNum==numScreens) { 
//        $('#nextButton').text("Start Over");
//        buttonText = "Start Over";
//        $('#nextButton').click(function() {
//              previousButton();
//        });
//    } else {
//        $('#nextButton').click(function() {
//              nextButton();
//        });
//    }
//    $('#successMessage').animate( {
//      left: goLeft,
//      top: goTop,
//      width: '400px',
//      height: '150px',
//      opacity: 1
//    }, 400 );
// 
//  }
//  


}

function typeReforco(){

audioElement = document.createElement('audio');
audioElement.setAttribute('src','/equiv/files/ref/'+reforco);
//audioElement.setAttribute('autoplay', 'autoplay');
//audioElement.addEventListener("load", function() {
       // audioElement.play();
      //  audioElement.stop();
     //   });
    
}

function typeGame (){

 if (tipo_puzzle==='texto'&& tipo_estimulo==='texto'){
     $('#slot_puzzle').attr('id','slot_puzzle_anagrama');
     $('#slot_estimulos').attr('id','slot_estimulos_anagrama');
 
    for (var i=0;i<12;i++) // 
{
     $('<div class=slotpuzzle id=slot'+(i+1)+' style="align-center; font-size:55px;line-height: 130px;\n\
        color:#000; background: 0; border: 0;  "></div>').appendTo('#slot_estimulos_anagrama');
   
    }
    var sortArray = [1,2,3,4,5,6,7,8,9,10,11,12];
for (var i=0;i<qtd_puzzles;i++) // 
{
    
    
     
     var  z=0;
    while ( id_puzzle[z]!==pos[i]){z++;}
     
    
    for (var j=0;j<formacaocomp_puzzle[z].length;j++){
        
        var push_pop_position = Math.floor(Math.random() * sortArray.length);
 var  sorted = sortArray[push_pop_position];
    
    $('<div  class=slotpuzzle style="align-center; font-size:55px;line-height: 130px;\n\
        color:#000; ">' +formacaocomp_puzzle[z][j]+' </div>').
    data( 'name', formacaocomp_puzzle[z][j]).data( 'fullname', name_puzzle[z]).
    attr( 'id', 'pos'+sorted ).appendTo( '#slot'+sorted ).draggable( {
      containment: '#content',
      stack: '#slot_estimulos div',
      cursor: 'move',
      revert: true
    } );
    
    $( '#slot'+sorted).css("border",'');
  $( '#slot'+sorted).css("background",'');
    sortArray.splice(push_pop_position,1);
    
    
    
   }
}
         $('<div id=navZX  style=" font-size:55px; align-center; line-height: 130px;">' + 
        src_estimulo[choosen_estimulo_index] +'</div>').data( 'number',
        id_estimulo[choosen_estimulo_index] ).prependTo( '#contentT' );

       for (var i = 0;i<formacaocomp_estimulo[choosen_estimulo_index].length;i++){

         $('<div id="slot_estimulo'+i+' style="  position: relative;margin-left: 190px;\n\
         align-center; line-height: 130px;"></div>').data( 'name',
        formacaocomp_estimulo[choosen_estimulo_index][i] ).data( 'fullname', src_estimulo[choosen_estimulo_index]).appendTo( '#slot_puzzle_anagrama' ).droppable( {
        accept: '#slot_estimulos_anagrama div',
        hoverClass: 'hovered' ,
        drop: handleSyllableDrop
    } ).click(function(){
        console.log('clicou');
//     $(ui).draggable.( { revert: 'invalid' });
  //  ui.draggable.draggable( 'enable' ); 
    //$(this).droppable( 'enable' );
});

        }
        
        //TESTAR RESET - DRAG'nDROP - postion alter; reset position/
//
//faz parte do for
  //'#pos'+(i+1)
 //   $('#pos'+(i+1)).data("left", $('#pos'+(i+1)).position().left)
   // .data("top", $('#pos'+(i+1)).position().top);
// fora do for
     
//    $("<div id=btnReset>Voltar</div>").appendTo( '#contentT' ).click(function() {
//    $("#pos1").animate({
//        "left": $("#pos1").data("left"),
//        "top": $("#pos1").data("top")
//    });
//        
//      });  
        
        
        
        
     
 }else {
 
 if (tipo_puzzle==='texto'){
 
    for (var i=0;i<6;i++) // 
{
     $('<div class=slotpuzzle id=slot'+(i+1)+' style="align-center; font-size:55px;line-height: 130px;\n\
        color:#000; background: 0; border: 0;  max-width: 80%;"></div>').appendTo('#slot_puzzle');
    
    }
    var sortArray = [1,2,3,4,5,6];
for (var i=0;i<qtd_puzzles;i++) // 
{
    

var push_pop_position = Math.floor(Math.random() * sortArray.length);
 var  sorted = sortArray[push_pop_position];
   
    
  var  z=0;
    while ( id_puzzle[z]!==pos[i]){
        z++;
            }
     
          
    $('<p>'+src_puzzle[z]+'</p>').data( 'number', pos[i]).
            data( 'name', src_puzzle[z]).attr( 'id', 'pos'+sorted ).
            appendTo( '#slot'+sorted ).hover(
    // hover begin (mouse-in)
    
    function () {
        $(this).css({"border-color": "#85c222"});
    },
    // hover end (mouse-out)
    function () {
        $(this).css({"border-color": ""});
    }
   
            
).click(function(){
   
  handleClickImage.call(this,event);
});
   
 $( '#slot'+sorted).css("border",'');
  $( '#slot'+sorted).css("background",'');
    sortArray.splice(push_pop_position,1);

}
        }
   
else if (tipo_puzzle==='imagem'){
    
    
 for (var i=0;i<6;i++) // 
{
     $('<div class=slotpuzzle id=slot'+(i+1)+' style="background: 0; border: 0;"></div>').appendTo('#slot_puzzle');
    
    }  
    
 var sortArray = [1,2,3,4,5,6];

for (i=0;i<qtd_puzzles;i++) // 
{
  var   push_pop_position = Math.floor(Math.random() * sortArray.length);
  var sorted = sortArray[push_pop_position];
    
   var  z=0;
    while ( id_puzzle[z]!==pos[i]){z++;}
    
    $('<img src="/equiv/files/'+src_puzzle[z]+'" border="0" alt="" />').
    data( 'number', pos[i]).data( 'name', src_puzzle[z]).attr( 'id', 'pos'+sorted ).appendTo( '#slot'+sorted  ).hover(
    // hover begin (mouse-in)
    
    function () {
        $(this).css({"border-color": "#85c222"});
    },
    // hover end (mouse-out)
    function () {
        $(this).css({"border-color": ""});
    }
   
            
).click(function(){
  handleClickImage.call(this,event);
});
  

   
 $( '#slot'+sorted).css("border",'');
  $( '#slot'+sorted).css("background",'');
    sortArray.splice(push_pop_position,1);

}

}   



 if (tipo_estimulo==='imagem'){
    

$('<div id="slot_estimulo"  style=" position: absolute; margin-left: 190px;"><img src="/equiv/files/' + 
        src_estimulo[choosen_estimulo_index] +'" border="0" alt="" /></div>').data( 'number',
        id_estimulo[choosen_estimulo_index] )
        .data( 'name', src_estimulo[choosen_estimulo_index]).appendTo( '#slot_estimulos' );

    
}
    
    
 else if (tipo_estimulo==='texto'){ 
    
   $('<div id="slot_estimulo"  style=" position: absolute; margin-left: 190px;\n\
        font-size:55px; align-center; line-height: 130px;">' + 
        src_estimulo[choosen_estimulo_index] +'</div>').data( 'number',
        id_estimulo[choosen_estimulo_index] )
        .data( 'name', src_estimulo[choosen_estimulo_index]).appendTo( '#slot_estimulos' );

}

else if (tipo_estimulo==="audio"){


audioElementvoice = document.createElement('audio');
audioElementvoice.setAttribute('src','/equiv/files/'+src_estimulo[choosen_estimulo_index]);
audioElementvoice.setAttribute('autoplay', 'autoplay');
//
$('<img src="/equiv/img/audio_.png" border="0" alt="" />\n\
').appendTo( '#slot_estimulos' );
  $('#slot_estimulos' ).data( 'number',id_estimulo[choosen_estimulo_index] )
  .data( 'name', src_estimulo[choosen_estimulo_index]);
  
  
        }


}}